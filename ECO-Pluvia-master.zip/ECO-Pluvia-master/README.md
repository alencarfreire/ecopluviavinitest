ECO-Pluvia Downloader 

This QGIS plugin facilitates the acquisition of precipitation data available at the website HidroWeb.
The website is administered by the Agência Nacional de Águas, a Brazilian governmental agency.
The plugin was developed by the Research Group on Hydro Environmental Modeling and Ecotechnologies at
Universidade Federal de Santa Maria in order to give a spatial visualization of the gages and
automate the download process facilitating the hydrologic studies.

USING ECO-Pluvia Downloader
- The plugin load automatically the ANA gages shapefile;
- Select the gages you want to download precipitation data;
- Open the python console to follow the process;
- Click Ok;



